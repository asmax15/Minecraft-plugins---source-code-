package de.asmax.SimpleGamemode.commands;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GamemodeSurvival implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;
		if(sender instanceof Player) {
			if(p.hasPermission("SGM.gm0")) {
				if(args.length == 0) {
					
					p.setGameMode(GameMode.SURVIVAL);
					p.sendMessage("�6Dein Spielmodus wurde zum �aSurvivalmodus �6ge�ndert!");
					
				}else {
					sender.sendMessage("�cBitte benutze �6/gm0");
				}
			}else {
				sender.sendMessage("�4Dazu hast du keine Rechte!");
			}
		}else {
			sender.sendMessage("Dieser Befehl kann nur von einem Spieler ausgef�hrt werden!");
		}
		return false;
	}

}

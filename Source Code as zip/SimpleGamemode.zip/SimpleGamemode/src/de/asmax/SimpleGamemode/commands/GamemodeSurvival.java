package de.asmax.SimpleGamemode.commands;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GamemodeSurvival implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;
		if(sender instanceof Player) {
			if(p.hasPermission("SGM.gm0")) {
				if(args.length == 0) {
					
					p.setGameMode(GameMode.SURVIVAL);
					p.sendMessage("�6Your gamemode has been updated to �asurvivalmode!");
					
				}else {
					sender.sendMessage("�cPlease use �6/gm0");
				}
			}else {
				sender.sendMessage("�4You dont have the Permission to do that!");
			}
		}else {
			sender.sendMessage("This command can only be carried out by player!");
		}
		return false;
	}

}

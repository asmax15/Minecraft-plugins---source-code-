package de.asmax.SimpleGamemode.main;

import org.bukkit.plugin.java.JavaPlugin;

import de.asmax.SimpleGamemode.commands.GamemodeAdventure;
import de.asmax.SimpleGamemode.commands.GamemodeCreative;
import de.asmax.SimpleGamemode.commands.GamemodeSpectator;
import de.asmax.SimpleGamemode.commands.GamemodeSurvival;

public class Main extends JavaPlugin {
	
	@Override
	public void onEnable() {
		System.out.println("[SimpleGM] The plugin was successfully activated!");
		getCommand("gm0").setExecutor(new GamemodeSurvival());
		getCommand("gm1").setExecutor(new GamemodeCreative());
		getCommand("gm3").setExecutor(new GamemodeSpectator());
		getCommand("gm2").setExecutor(new GamemodeAdventure());
		super.onEnable();
	}
	
	
	
	
	
	@Override
	public void onDisable() {
		System.out.println("[SimpleGM] The plugin was deactivated successfully!");
		super.onDisable();
	}
}

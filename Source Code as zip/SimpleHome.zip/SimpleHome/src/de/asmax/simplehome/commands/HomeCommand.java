package de.asmax.simplehome.commands;

import java.io.File;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import de.asmax.simplehome.main.Main;

public class HomeCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
			if(!(sender instanceof Player)) {
				sender.sendMessage(Main.pr + "�4Just a Player can execute this command!");
				return true;
			}
			Player p = (Player)sender;
			
			if(p.hasPermission("simplehome.home")) {
				if(args.length == 0) {
					
					File file = new File("plugins/SimpleHome", "Homes.yml");
					FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
					
					World world = Bukkit.getWorld(cfg.getString(p.getName() + ".World"));
					double x = cfg.getDouble(p.getName() + ".X");
					double y = cfg.getDouble(p.getName() + ".Y");
					double z = cfg.getDouble(p.getName() + ".Z");
					
					float yaw = (float) cfg.getDouble(p.getName() + ".Yaw");
					float pitch = (float) cfg.getDouble(p.getName() + ".Pitch");
					
					p.teleport(new Location(world, x, y, z, yaw, pitch));
					
					p.sendMessage(Main.pr + "�aYou have been successfully teleported to your home!");
					
				} else {
					p.sendMessage(Main.pr + "�6Please use: �a/home");
				}
			} else {
				p.sendMessage(Main.pr + "�cYou do not have the permission to do that!");
			}
		return false;
	}

}

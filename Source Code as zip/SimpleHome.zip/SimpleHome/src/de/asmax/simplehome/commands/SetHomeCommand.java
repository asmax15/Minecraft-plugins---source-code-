package de.asmax.simplehome.commands;

import java.io.File;
import java.io.IOException;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import de.asmax.simplehome.main.Main;

public class SetHomeCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
			if(!(sender instanceof Player)) {
				sender.sendMessage(Main.pr + "�4Just a Player can execute this command!");
				return true;
			}
			Player p = (Player)sender;
			
			if(p.hasPermission("simplehome.sethome")) {
				if(args.length == 0) {
					
					File file = new File("plugins/SimpleHome", "Homes.yml");
					FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
					
					String name = p.getName();
					String world = p.getLocation().getWorld().getName();
					double x = p.getLocation().getX();
					double y = p.getLocation().getY();
					double z = p.getLocation().getZ();
					double yaw = p.getLocation().getYaw();
					double pitch = p.getLocation().getPitch();
					
					cfg.set(name + ".World", world);
					cfg.set(name + ".X", x);
					cfg.set(name + ".Y", y);
					cfg.set(name + ".Z", z);
					cfg.set(name + ".Yaw", yaw);
					cfg.set(name + ".Pitch", pitch);
					
					p.sendMessage(Main.pr + "�aYou have successfully implemented your home!");
					
					try {
						cfg.save(file);
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				} else {
					p.sendMessage(Main.pr + "�6Please use: �a/sethome");
				}
			} else {
				p.sendMessage(Main.pr + "�cYou do not have the permission to do that!");
			}
			
		return false;
	}

}

package de.asmax.simplehome.main;

import org.bukkit.plugin.java.JavaPlugin;

import de.asmax.simplehome.commands.HomeCommand;
import de.asmax.simplehome.commands.SetHomeCommand;

public class Main extends JavaPlugin{
	
	private static Main plugin;
	
	public static String pr = "�6[SimpleHome] ";
	
	@Override
	public void onEnable() {
		plugin = this;
		
		getCommand("sethome").setExecutor(new SetHomeCommand());
		getCommand("home").setExecutor(new HomeCommand());
	}
	
	public void onDisable() {};
	
	public static Main getPlugin() {
		return plugin;
	}

}

package de.asmax.simplejoin.main;

import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import de.asmax.simplejoin.listener.JoinListener;
import de.asmax.simplejoin.listener.LeaveListener;

public class Main extends JavaPlugin {
	
	@Override
	public void onEnable() {
		PluginManager manager = Bukkit.getPluginManager();
		manager.registerEvents(new JoinListener(), this);
		manager.registerEvents(new LeaveListener(), this);
		
	}

}

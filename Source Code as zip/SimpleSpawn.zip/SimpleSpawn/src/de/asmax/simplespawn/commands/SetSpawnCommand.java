package de.asmax.simplespawn.commands;

import de.asmax.simplespawn.main.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;

public class SetSpawnCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!(sender instanceof Player)) {
            sender.sendMessage(Main.pr + "§cJust a Player can execute this command!");
            return true;
        }
        Player p = (Player)sender;
        if(p.hasPermission("simplespawn.setspawn")) {
            if(args.length == 0) {

                File file = new File("plugins/SimpleSpawn", "spawn.yml");
                FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

                String world = p.getLocation().getWorld().getName();
                double x = p.getLocation().getX();
                double y = p.getLocation().getY();
                double z = p.getLocation().getZ();
                double yaw = p.getLocation().getYaw();
                double pitch = p.getLocation().getPitch();

                cfg.set("spawn" + ".World", world);
                cfg.set("spawn" + ".X", x);
                cfg.set("spawn" + ".Y", y);
                cfg.set("spawn" + ".Z", z);
                cfg.set("spawn" + ".Yaw", yaw);
                cfg.set("spawn" + ".Pitch", pitch);

                p.sendMessage(Main.pr + "You have succesfully set the spawn!");

                try {
                    cfg.save(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } else {
                p.sendMessage(Main.pr + "§6Please use: /setspawn");
            }
        } else {
            p.sendMessage(Main.pr + "§cYou dont have Permission to do that.");
        }
        return false;
    }
}

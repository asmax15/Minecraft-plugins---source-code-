package de.asmax.simplespawn.commands;

import de.asmax.simplespawn.main.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;

public class SpawnCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!(sender instanceof Player)) {
            sender.sendMessage(Main.pr + "§cJust a Player can execute this command!");
            return true;
        }
        Player p = (Player)sender;

        if(p.hasPermission("simplespawn.spawn")) {
            if(args.length == 0) {

                File file = new File("plugins/SimpleSpawn", "spawn.yml");
                FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

                World world = Bukkit.getWorld(cfg.getString("spawn.World"));
                double x = cfg.getDouble("spawn.X");
                double y = cfg.getDouble("spawn.Y");
                double z = cfg.getDouble("spawn.Z");
                float yaw = (float) cfg.getDouble("spawn.Yaw");
                float pitch = (float) cfg.getDouble("spawn.Pitch");

                p.teleport(new Location(world, x, y, z, yaw, pitch));

            } else {
                p.sendMessage(Main.pr + "§6Please use: /spawn");
            }
        } else {
            p.sendMessage(Main.pr + "§cYou dont have Permission to do that.");
        }
        return false;
    }
}

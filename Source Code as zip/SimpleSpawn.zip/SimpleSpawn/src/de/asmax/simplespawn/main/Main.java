package de.asmax.simplespawn.main;

import de.asmax.simplespawn.commands.SetSpawnCommand;
import de.asmax.simplespawn.commands.SpawnCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    private static Main plugin;

    public static String pr = "§b[SimpleSpawn] §a";

    @Override
    public void onEnable() {
        getCommand("setspawn").setExecutor(new SetSpawnCommand());
        getCommand("spawn").setExecutor(new SpawnCommand());
    }

    @Override
    public void onDisable() {

    }

    public static Main getPlugin() {
        return plugin;
    }
}

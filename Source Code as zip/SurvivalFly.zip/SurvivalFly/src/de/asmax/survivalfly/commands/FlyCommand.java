package de.asmax.survivalfly.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand implements CommandExecutor {

	@Override
	public boolean onCommand( CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			if(args.length ==0) {
				Player p = (Player) sender;
				if(p.hasPermission("survival.fly")) {
					if(p.getAllowFlight()) {
						p.setAllowFlight(false);
						p.sendMessage("�6You have �cleft �6the flight mode!");
						return true;
					}else {
						p.setAllowFlight(true);
						p.sendMessage("�6You have �aentered �6the flight mode!");
					}
				}else {
					sender.sendMessage("�4You dont have the Permission to do that!");
				}
			}else {
				sender.sendMessage("�cPlease use �6/Fly");
			}
		}else {
			sender.sendMessage("This command can only be carried out by player!");
		}
		return false;
	}

}

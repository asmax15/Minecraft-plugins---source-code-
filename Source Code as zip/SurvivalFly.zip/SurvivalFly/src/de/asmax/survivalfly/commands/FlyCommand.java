package de.asmax.survivalfly.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand implements CommandExecutor {

	@Override
	public boolean onCommand( CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			if(args.length ==0) {
				Player p = (Player) sender;
				if(p.hasPermission("survival.fly")) {
					if(p.getAllowFlight()) {
						p.setAllowFlight(false);
						p.sendMessage("�6Du hast den Flugmodus �cverlassen�6!");
						return true;
					}else {
						p.setAllowFlight(true);
						p.sendMessage("�6Du hast den Flugmodus �abetreten�6!");
					}
				}else {
					sender.sendMessage("�4Dazu hast du keine Rechte!");
				}
			}else {
				sender.sendMessage("�cBitte benutze �6/Fly");
			}
		}else {
			sender.sendMessage("Dieser Befehl kann nur von einem Spieler ausgef�hrt werden!");
		}
		return false;
	}

}

package de.asmax.survivalfly.main;

import org.bukkit.plugin.java.JavaPlugin;

import de.asmax.survivalfly.commands.FlyCommand;

public class Main extends JavaPlugin {
	@Override
	public void onEnable() {
		System.out.println("[SurvivalFly] The Plugin was succesfully activated!");
		getCommand("fly").setExecutor(new FlyCommand());
		super.onEnable();
	}
	
	
	
	
	
	
	@Override
	public void onDisable() {
		System.out.println("[SurvivalFly] The Plugin was succesfully deactivated!");
		super.onDisable();
	}
}

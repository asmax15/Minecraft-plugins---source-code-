package de.asmax.survivalfly.main;

import org.bukkit.plugin.java.JavaPlugin;

import de.asmax.survivalfly.commands.FlyCommand;

public class Main extends JavaPlugin {
	@Override
	public void onEnable() {
		System.out.println("[SurvivalFly] Das Plugin wurde erfolgreich aktiviert!");
		getCommand("fly").setExecutor(new FlyCommand());
		super.onEnable();
	}
	
	
	
	
	
	
	@Override
	public void onDisable() {
		System.out.println("[SurvivalFly] Das Plugin wurde erfolgreich deaktiviert!");
		super.onDisable();
	}
}
